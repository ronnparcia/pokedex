# Simple Pokedex Web Application

## Running this project
* Run `node app.js`
* Access the web application via `localhost:3000`
